import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DecideuserComponent } from './decideuser.component';

describe('DecideuserComponent', () => {
  let component: DecideuserComponent;
  let fixture: ComponentFixture<DecideuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DecideuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DecideuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
