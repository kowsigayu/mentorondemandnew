import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-decideuser',
  templateUrl: './decideuser.component.html',
  styleUrls: ['./decideuser.component.css']
})
export class DecideuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
