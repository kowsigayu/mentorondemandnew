import { Signupclass } from './signupclass';

describe('Signupclass', () => {
  it('should create an instance', () => {
    expect(new Signupclass()).toBeTruthy();
  });
});
