import { TestBed } from '@angular/core/testing';

import { UserblockserviceService } from './userblockservice.service';

describe('UserblockserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserblockserviceService = TestBed.get(UserblockserviceService);
    expect(service).toBeTruthy();
  });
});
