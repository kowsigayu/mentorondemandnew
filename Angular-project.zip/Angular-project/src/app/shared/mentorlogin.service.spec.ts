import { TestBed } from '@angular/core/testing';

import { MentorloginService } from './mentorlogin.service';

describe('MentorloginService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorloginService = TestBed.get(MentorloginService);
    expect(service).toBeTruthy();
  });
});
