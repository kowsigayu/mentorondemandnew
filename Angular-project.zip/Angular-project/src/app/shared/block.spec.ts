import { Block } from './block';

describe('Block', () => {
  it('should create an instance', () => {
    expect(new Block()).toBeTruthy();
  });
});
