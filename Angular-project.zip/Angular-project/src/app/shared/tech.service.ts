import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TechService {

  private baseUrl = 'http://localhost:8045/';  
  constructor(private http:HttpClient) { }
  createTech(Tech:Object):Observable<Object>{
    return this.http.post(`${this.baseUrl}`+'admin/admin/tech',Tech);
  }}
