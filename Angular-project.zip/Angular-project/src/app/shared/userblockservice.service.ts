import { Injectable } from '@angular/core';
import { Block } from './block';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserblockserviceService {
  private usersUrl:string;
  private users1Url:string;

  constructor(private http: HttpClient) {
    this.usersUrl="http://localhost:8045/trainee/trainee";
    this.users1Url="http://localhost:8045/trainee/trainee/delete/";
   }
   public findAll(): Observable<Block[]>{
    return this.http.get<Block[]>(this.usersUrl);
  }

  deleteUser(userId: number): Observable<any> {
    console.log(userId);
   return this.http.delete(`${this.users1Url}`+ userId, { responseType: 'text' });
 }
}
