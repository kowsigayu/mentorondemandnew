import { MentorsignupserviceService } from './mentorsignupservice.service';
import { TestBed } from '@angular/core/testing';

describe('MentorsignupserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorsignupserviceService = TestBed.get(MentorsignupserviceService);
    expect(service).toBeTruthy();
  });
});
