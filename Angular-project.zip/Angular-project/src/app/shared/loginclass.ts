export class Loginclass {
    firstname:String
    lastname:String
    email:String
    password:String
    rating:number
    technology:String
    fees:number
}
