import { Loginclass } from './loginclass';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  constructor(private http:HttpClient) { }

  login(user:String):Observable<Loginclass>{
    return this.http.get<Loginclass>('http://localhost:8045/trainee/userName/'+user);
  }
}
