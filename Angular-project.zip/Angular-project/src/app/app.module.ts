import { HttpClient } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { AddremovetechComponent } from './addremovetech/addremovetech.component';
import { BlockunblockComponent } from './blockunblock/blockunblock.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { NewtechnologyComponent } from './newtechnology/newtechnology.component';
import { MainComponent } from './main/main.component';
import { SearchpageComponent } from './searchpage/searchpage.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { PaymentComponent } from './payment/payment.component';
import { UserblockComponent } from './userblock/userblock.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { DecideuserComponent } from './decideuser/decideuser.component';
import { DecidementorComponent } from './decidementor/decidementor.component';
import { PaymentsmadeComponent } from './paymentsmade/paymentsmade.component';
import { PaymentcommissionComponent } from './paymentcommission/paymentcommission.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { MentorloginComponent } from './mentorlogin/mentorlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';


@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    LoginComponent,
    AdminprofileComponent,
    AddremovetechComponent,
    BlockunblockComponent,
    EditprofileComponent,
    NewtechnologyComponent,
    MainComponent,
    SearchpageComponent,
    UserprofileComponent,
    PaymentComponent,
    UserblockComponent,
    MentorprofileComponent,
    DecideuserComponent,
    DecidementorComponent,
    PaymentsmadeComponent,
    PaymentcommissionComponent,
    MentorsignupComponent,
    MentorloginComponent,
    AdminloginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
