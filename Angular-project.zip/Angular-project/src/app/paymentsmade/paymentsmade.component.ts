import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentsmade',
  templateUrl: './paymentsmade.component.html',
  styleUrls: ['./paymentsmade.component.css']
})
export class PaymentsmadeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
