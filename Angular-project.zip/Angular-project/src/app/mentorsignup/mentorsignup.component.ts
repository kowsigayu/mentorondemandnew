import { MentorsignupserviceService } from './../shared/mentorsignupservice.service';
import { Signupclass } from '../shared/signupclass';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,Validators,FormBuilder} from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorsignup',
  templateUrl: './mentorsignup.component.html',
  styleUrls: ['./mentorsignup.component.css']
})
export class MentorsignupComponent implements OnInit {
  signupForm:FormGroup;
  submitted=false;
  constructor(private route:ActivatedRoute, private router:Router, private formBulider:FormBuilder,private Userservice: MentorsignupserviceService) { }
   Signupclass:Signupclass=new Signupclass();
  
  ngOnInit() {
    this.signupForm=this.formBulider.group(
      {
        formfirstname:['', Validators.required],
        formlastname:['', Validators.required],
        formemail:['', [Validators.required,Validators.email]],
        formpassword:['', [Validators.required]],
        }
    );
  }
  get f() { return this.signupForm.controls;}

onSubmit(){
  this.submitted = true;
  this.Signupclass.firstname=this.signupForm.get('formfirstname').value;
  this.Signupclass.lastname=this.signupForm.get('formlastname').value;
  this.Signupclass.email=this.signupForm.get('formemail').value;
  this.Signupclass.password=this.signupForm.get('formpassword').value;
  this.Userservice.createUser(this.Signupclass).subscribe(data => console.log(data),error=>console.log(error));
  this.router.navigate(['/login'])
}


}
