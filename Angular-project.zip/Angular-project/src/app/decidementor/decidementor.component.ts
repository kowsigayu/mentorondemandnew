import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-decidementor',
  templateUrl: './decidementor.component.html',
  styleUrls: ['./decidementor.component.css']
})
export class DecidementorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
