import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DecidementorComponent } from './decidementor.component';

describe('DecidementorComponent', () => {
  let component: DecidementorComponent;
  let fixture: ComponentFixture<DecidementorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DecidementorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DecidementorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
