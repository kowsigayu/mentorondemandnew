import { AdminloginService } from './../shared/adminlogin.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'; 
import { Loginclass } from './../shared/loginclass';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css'],
  providers: [AdminloginService]
})
export class AdminloginComponent implements OnInit {
  
  loginclass: Loginclass = new Loginclass();
  loginForm: FormGroup;
  constructor(private loginservice: AdminloginService, private formbuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formbuilder.group({
      formusername: ['', [Validators.required, Validators.email]],
      formpassword: ['', [Validators.required]],

    });
  
  }
  // get f() { return this.loginForm.controls; }

  onSubmit() {

    this.loginservice.login(this.loginForm.get("formusername").value).subscribe(
    data => {
      this.loginclass=data;
      console.log(Loginclass);
      if(this.loginForm.get("formpassword").value==this.loginclass.password){
        console.log("success");
        this.router.navigateByUrl("/adminprofile");
      }
      else{
        console.log("fail");
      }
    });
  }
}
