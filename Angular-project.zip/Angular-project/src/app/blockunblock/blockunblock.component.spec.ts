import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockunblockComponent } from './blockunblock.component';

describe('BlockunblockComponent', () => {
  let component: BlockunblockComponent;
  let fixture: ComponentFixture<BlockunblockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockunblockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockunblockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
