import { Component, OnInit } from '@angular/core';
import { Block } from '../shared/block';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BlockserviceService} from '../shared/blockservice.service';

@Component({
  selector: 'app-blockunblock',
  templateUrl: './blockunblock.component.html',
  styleUrls: ['./blockunblock.component.css']
})
export class BlockunblockComponent implements OnInit {
  users: Observable<Block[]>;

  constructor(private searchService: BlockserviceService, private httpService:HttpClient) {}

  search1:Block[];
  ngOnInit() {
    this.searchService.findAll().subscribe(data => {
      this.search1=data;
    });
    this.reloadData();
  }
  reloadData() {
    this.searchService.findAll().subscribe(data =>{
      this.search1=data;
    });
    this.users = this.searchService.findAll();
  }

  deletementor(id: number) {
    this.searchService.deletementor(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}
