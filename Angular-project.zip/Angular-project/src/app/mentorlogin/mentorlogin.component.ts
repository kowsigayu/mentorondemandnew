import { MentorloginService } from './../shared/mentorlogin.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Loginclass } from './../shared/loginclass';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorlogin',
  templateUrl: './mentorlogin.component.html',
  styleUrls: ['./mentorlogin.component.css']
})
export class MentorloginComponent implements OnInit {
  loginclass: Loginclass = new Loginclass();
  loginForm: FormGroup;
 constructor(private loginservice: MentorloginService, private formbuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formbuilder.group({
      formusername: ['', [Validators.required, Validators.email]],
      formpassword: ['', [Validators.required]],

    });
  
  }
  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.loginservice.login(this.loginForm.get("formusername").value).subscribe(
      data => {

        this.loginclass=data;
        console.log(this.loginclass);
        if(this.loginForm.get("formpassword").value==this.loginclass.password){
          console.log("success");
          this.router.navigateByUrl("/mentorprofile");
        }
        else{
          console.log("fail");
        }
      });
    }

}
