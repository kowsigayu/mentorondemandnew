import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { PaymentComponent } from './payment/payment.component';
import { SearchpageComponent } from './searchpage/searchpage.component';
import { BlockunblockComponent } from './blockunblock/blockunblock.component';
import { MainComponent } from './main/main.component';
import { AddremovetechComponent } from './addremovetech/addremovetech.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { UserblockComponent } from './userblock/userblock.component';
import { NewtechnologyComponent } from './newtechnology/newtechnology.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { DecideuserComponent } from './decideuser/decideuser.component';
import { PaymentsmadeComponent } from './paymentsmade/paymentsmade.component';
import { DecidementorComponent } from './decidementor/decidementor.component';
import { PaymentcommissionComponent } from './paymentcommission/paymentcommission.component';
import { MentorloginComponent } from './mentorlogin/mentorlogin.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: MainComponent},
  { path: 'signup', component: SignupComponent },
  { path: 'login', component: LoginComponent },
  { path: 'searchpage', component: SearchpageComponent},
  { path:'userprofile', component: UserprofileComponent},
  { path: 'editprofile', component: EditprofileComponent},
  { path: 'payment', component: PaymentComponent},
  { path: 'userblock', component: UserblockComponent },
  { path: 'adminprofile', component: AdminprofileComponent },
  { path: 'addremovetech', component: AddremovetechComponent },
  { path: 'newtechnology', component: NewtechnologyComponent},
  { path: 'blockunblock', component:BlockunblockComponent },
  {path: 'mentorprofile', component:MentorprofileComponent},
  { path: 'decideuser', component:DecideuserComponent},
  { path: 'paymentsmade', component:PaymentsmadeComponent},
  { path: 'paymentcommission', component:PaymentcommissionComponent},
  { path: 'decidementor', component:DecidementorComponent},
  { path: 'mentorsignup', component:MentorsignupComponent},
  { path: 'mentorlogin', component:MentorloginComponent},
  { path: 'adminlogin', component:AdminloginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
