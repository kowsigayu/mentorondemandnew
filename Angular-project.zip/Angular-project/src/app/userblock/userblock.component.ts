import { UserblockserviceService } from './../shared/userblockservice.service';
import { Component, OnInit } from '@angular/core';
import { Block } from '../shared/block';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-userblock',
  templateUrl: './userblock.component.html',
  styleUrls: ['./userblock.component.css']
})
export class UserblockComponent implements OnInit {
  users: Observable<Block[]>;

  constructor(private searchService: UserblockserviceService, private httpService: HttpClient) { }

  search1: Block[];

  ngOnInit() {
    this.searchService.findAll().subscribe(data => {
      this.search1 = data;
    });
    this.reloadData();
  }
  reloadData() {
    this.searchService.findAll().subscribe(data => {
      this.search1 = data;
    });
    this.users = this.searchService.findAll();
  }

  deleteUser(userId: number) {
    this.searchService.deleteUser(userId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

}
