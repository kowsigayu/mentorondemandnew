
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginserviceService } from './../shared/loginservice.service';
import { Loginclass } from './../shared/loginclass';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   
  loginclass: Loginclass = new Loginclass();
  loginForm: FormGroup;
 constructor(private loginservice: LoginserviceService, private formbuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formbuilder.group({
      formusername: ['', [Validators.required, Validators.email]],
      formpassword: ['', [Validators.required]],

    });
  }
  get f() { return this.loginForm.controls; }

  onSubmit() {
  
    this.loginservice.login(this.loginForm.get("formusername").value).subscribe(
      data => {

        this.loginclass=data;
        console.log(this.loginclass);
        if(this.loginForm.get("formpassword").value==this.loginclass.password){
          console.log("success");
          this.router.navigateByUrl("/userprofile");
        }
        else{
          console.log("fail");
        }
      });
    }
  }
