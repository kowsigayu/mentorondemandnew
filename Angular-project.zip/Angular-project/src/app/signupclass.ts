export class Signupclass {
    name:String;
    email:String;
    password:String;
    confirmPassword:String;
}
