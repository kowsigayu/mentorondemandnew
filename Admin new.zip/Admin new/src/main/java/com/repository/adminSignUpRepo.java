package com.repository;



import org.springframework.data.repository.CrudRepository;

import com.entity.adminSignUp;



public interface adminSignUpRepo extends CrudRepository<adminSignUp, Integer> {

}
