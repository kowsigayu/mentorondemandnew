package com.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class paymentCom {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name="UserId")
	private Integer userid;
	@Column(name="UserName")
	private String username;
	@Column(name="mentorid")
	private Integer mentorid;
	@Column(name="mentorname")
	private String mentorname;
	private Float commissionPercentage;
	
	public paymentCom() {
		
	}
	
	public paymentCom(Integer userid, String username, Integer mentorid, String mentorname,
			Float commissionPercentage) {
		super();
		this.userid = userid;
		this.username = username;
		this.mentorid = mentorid;
		this.mentorname = mentorname;
		this.commissionPercentage = commissionPercentage;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Integer getMentorid() {
		return mentorid;
	}
	public void setMentorid(Integer mentorid) {
		this.mentorid = mentorid;
	}
	public String getMentorname() {
		return mentorname;
	}
	public void setMentorname(String mentorname) {
		this.mentorname = mentorname;
	}
	public Float getCommissionPercentage() {
		return commissionPercentage;
	}
	public void setCommissionPercentage(Float commissionPercentage) {
		this.commissionPercentage = commissionPercentage;
	}
	
	

}
