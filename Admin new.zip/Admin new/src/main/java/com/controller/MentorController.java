package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Mentor;

import com.service.MentorService;


@RestController
public class MentorController {
	@Autowired

	private MentorService ms;

	@RequestMapping("/Mentor")
	public List<Mentor> getMentor() {
		return ms.getMentor();
	}

	@RequestMapping("/Mentor/{id}")
	public Mentor getMentor(@PathVariable Integer id) {

		return ms.getMentor(id);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/Mentor")

	public void addMentor(@RequestBody Mentor s) {
		ms.addMentor(s);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/Mentor/{id}")
	public void updateMentor(@RequestBody Mentor s, @PathVariable Integer id) {
		ms.updateMentor(s, id);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/Mentor/{id}")
	public void deleteMentor(@PathVariable Integer id) {
		ms.deleteMentor(id);
	}

}

