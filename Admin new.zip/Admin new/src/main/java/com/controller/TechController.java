package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.entity.Tech;
import com.service.TechService;


public class TechController {
	@Autowired

	private TechService ms;

	@RequestMapping("/Tech")
	public List<Tech> getTech() {
		return ms.getTech();
	}

	@RequestMapping("/paymentCom/{id}")
	public Tech getTech(@PathVariable Integer id) {

		return ms.getTech(id);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/Tech")

	public void addpaymentCom(@RequestBody Tech s) {
		ms.addTech(s);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/Tech/{id}")
	public void updateTech(@RequestBody Tech s, @PathVariable Integer id) {
		ms.updateTech(s, id);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/paymentCom/{id}")
	public void deleteTech(@PathVariable Integer id) {
		ms.deleteTech(id);
	}


}
