package com.service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.adminSignUp;
import com.repository.adminSignUpRepo;
@Service
public class adminSignUpService {
	@Autowired
	private adminSignUpRepo mr;

	public List<adminSignUp> getadminSignUp() {
		List<adminSignUp> ls = new ArrayList<>();
		mr.findAll().forEach(ls::add);
		return ls;
	}

	public adminSignUp getadminSignUp(Integer id) {
		// TODO Auto-generated method stub
		// return ls.stream().filter(t->t.getStateid().equals(id)).findFirst().get();
		return mr.findById(id).orElse(null);
	}

	public void addadminSignUp(adminSignUp s) {
		mr.save(s);
	}

	public void updateadminSignUp(adminSignUp s, Integer id) {
		mr.save(s);
	}

	public void deleteadminSignUp(Integer id) {
		mr.deleteById(id);
	}

}
