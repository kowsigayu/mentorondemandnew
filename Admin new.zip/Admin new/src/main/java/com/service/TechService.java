package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Tech;

import com.repository.TechRepo;

@Service
public class TechService {
	@Autowired
	private TechRepo mr;

	public List<Tech> getTech() {
		List<Tech> ls = new ArrayList<>();
		mr.findAll().forEach(ls::add);
		return ls;
	}

	public Tech getTech(Integer id) {
		// TODO Auto-generated method stub
		// return ls.stream().filter(t->t.getStateid().equals(id)).findFirst().get();
		return mr.findById(id).orElse(null);
	}

	public void addTech(Tech s) {
		mr.save(s);
	}

	public void updateTech(Tech s, Integer id) {
		mr.save(s);
	}

	public void deleteTech(Integer id) {
		mr.deleteById(id);
	}

}
