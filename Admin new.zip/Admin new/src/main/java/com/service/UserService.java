package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.entity.User;

import com.repository.UserRepo;

public class UserService {
	@Autowired
	private UserRepo mr;

	public List<User> getTech() {
		List<User> ls = new ArrayList<>();
		mr.findAll().forEach(ls::add);
		return ls;
	}

	public User getUser(Integer id) {
		// TODO Auto-generated method stub
		// return ls.stream().filter(t->t.getStateid().equals(id)).findFirst().get();
		return mr.findById(id).orElse(null);
	}

	public void addUser(User s) {
		mr.save(s);
	}

	public void updateUser(User s, Integer id) {
		mr.save(s);
	}

	public void deleteUser(Integer id) {
		mr.deleteById(id);
	}


}
