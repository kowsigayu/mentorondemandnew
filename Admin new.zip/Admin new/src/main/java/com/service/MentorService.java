package com.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.entity.Mentor;

import com.repository.MentorRepo;


public class MentorService {
	@Autowired
	private MentorRepo mr;

	public List<Mentor> getMentor() {
		List<Mentor> ls = new ArrayList<>();
		mr.findAll().forEach(ls::add);
		return ls;
	}

	public Mentor getMentor(Integer id) {
		// TODO Auto-generated method stub
		// return ls.stream().filter(t->t.getStateid().equals(id)).findFirst().get();
		return mr.findById(id).orElse(null);
	}

	public void addMentor(Mentor s) {
		mr.save(s);
	}

	public void updateMentor(Mentor s, Integer id) {
		mr.save(s);
	}

	public void deleteMentor(Integer id) {
		mr.deleteById(id);
	}

}
