package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import com.entity.paymentCom;

import com.repository.paymentComRepo;

public class paymentComService {
	@Autowired
	private paymentComRepo mr;

	public List<paymentCom> getpaymentCom() {
		List< paymentCom> ls = new ArrayList<>();
		mr.findAll().forEach(ls::add);
		return ls;
	}

	public paymentCom getpaymentCom(Integer id) {
		// TODO Auto-generated method stub
		// return ls.stream().filter(t->t.getStateid().equals(id)).findFirst().get();
		return mr.findById(id).orElse(null);
	}

	public void addpaymentCom(paymentCom s) {
		mr.save(s);
	}

	public void updatepaymentCom(paymentCom s, Integer id) {
		mr.save(s);
	}

	public void deletepaymentCom(Integer id) {
		mr.deleteById(id);
	}

}
